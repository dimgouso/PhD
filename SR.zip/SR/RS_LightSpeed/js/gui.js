//controls
var gui=new dat.GUI();
var simSwitch,simulationSpeed,showGrd,grdStep,noOfFrnts,wagonV,emitLight,frntColor,bulletV;

var controls=function() {
	this.simulationSwitch=false;
	this.simulationSpeed=simSpeed;
	this.showGrid=gridVisible;
	this.gridStep=gridStep;
    this.noOfFronts=originalNoOfFronts;
    this.wagonV=0;
    this.emitLight=lightEmission;
    this.frontsColor=[frontRed,frontGreen,frontBlue];
    this.bulletV=0;
};
var cntrls=new controls();

function initGUI(){
	cntrls.wagonV=wagonVel;
	cntrls.noOfFronts=noOfFronts;
	cntrls.bulletV=bulletSpeed;
	
	if (simSwitch){
		gui.remove(simSwitch);
		simSwitch=null;
	}
	if (simulationSpeed){
		gui.remove(simulationSpeed);
		simulationSpeed=null;
	}
	if (showGrd){
		gui.remove(showGrd);
		showGrd=null;
	}
	if (grdStep){
		gui.remove(grdStep);
		grdStep=null;
	}
	if (noOfFrnts){
		gui.remove(noOfFrnts);
		noOfFrnts=null;
	}
	if (wagonV){
		gui.remove(wagonV);
		wagonV=null;
	}
	if (emitLight){
		gui.remove(emitLight);
		emitLight=null;
	}
	if (frntColor){
		gui.remove(frntColor);
		frntColor=null;
	}
	if (bulletV){
		gui.remove(bulletV);
		bulletV=null;
	}
    
	gui.width=350;	

    simSwitch=gui.add(cntrls,"simulationSwitch").listen().name("Προσομοίωση");
    simSwitch.onChange(function(newValue){
    	simulating=newValue;
    	handleTimer(false);
    });

	simulationSpeed=gui.add(cntrls,"simulationSpeed",1,20).step(1).name("Βραδύτητα προσομοίωσης");
	simulationSpeed.onChange(function(newValue){
		simSpeed=newValue;
		defineSimulationSpeed();
    });
	
	showGrd=gui.add(cntrls,"showGrid").listen().name("Πλέγμα");
	showGrd.onChange(function(newValue){
		gridVisible=newValue;
		drawScene();
	});
	
	grdStep=gui.add(cntrls,"gridStep",1,5).step(1).name("Βήμα πλέγματος");
	grdStep.onChange(function(newValue){
		gridStep=newValue;
		drawScene();
    });

	noOfFrnts=gui.add(cntrls,"noOfFronts",1,maxNoOfFronts).step(1).name("Πλήθος μετώπων");
	noOfFrnts.onChange(function(newValue){
		noOfFronts=newValue;
		reset();
    });
	
	wagonV=gui.add(cntrls,"wagonV",-5,5).step(1).name("Ταχύτητα βαγονιού");
	wagonV.onChange(function(newValue){
		wagonVel=newValue;
		reset();
    });

    emitLight=gui.add(cntrls,"emitLight").listen().name("Εκπομπή φωτός");
    emitLight.onChange(function(newValue){
    	lightEmission=newValue;
    	initialiseExperiment();
    });

	if (lightEmission){
	    frntColor=gui.addColor(cntrls,"frontsColor").name("Χρώμα μετώπων");
	    frntColor.onChange(function(value){
			frontRed=parseInt(value[0]);
			frontGreen=parseInt(value[1]);
			frontBlue=parseInt(value[2]);
			setFrontsColor();
			if (simulating) drawScene();
	    });		
	}
	else{
		bulletV=gui.add(cntrls,"bulletV",1,15).step(1).name("Σχετική ταχ. βλήμ.");
		bulletV.onChange(function(newValue){
			bulletSpeed=newValue;
			reset();
	    });		
	}
}