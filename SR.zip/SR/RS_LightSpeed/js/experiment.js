var frontsLeft=[];
var maxNoOfFronts=120;

var originalNoOfFronts=1;
var noOfFronts=originalNoOfFronts;
var dt=2;
var source1Y=0;
var bulletLeft=0;
var bulletSpeed=1;
var bullsEye=false;
var lightEmission=true;

var tracks=document.getElementById("tracks");
var wagon=document.getElementById("wagon");
var observer=document.getElementById("observer");
var trackTop=0;
var wagonTop=0;
var wagonLeft=-wagon.width/2;
var wagonLeftWall=36,wagonRightWall=363;
var wagonVel=0;
var observerLeft=(canvas.width-observer.width);
var observerTop=canvas.height-observer.height+1;

var clockXOffset=50,clockYOffset=40;
var clock1=new clock(clockXOffset,clockYOffset,context);

function initialiseExperiment(){
	experimentInitialised=false;
	initGUI();
	reset();
	initialiseBackground();
	experimentInitialised=true;
	drawScene();
}

function initialiseFronts(){
	var i=0;
	for (i=frontsLeft.length-1;i>-1;i--){
		frontsLeft.splice(i,1);
	}
}

function initialiseBullet(){
	bulletLeft=wagonLeft+wagon.width-10;
}

function previousFrame(){
	var i=0;
	clock1.setValue(clock1.m_Value-1);
	if(frontsLeft.length>1){//πρέπει να υπάρχουν τουλάχιστον δύο μέτωπα
		frontsLeft.splice(frontsLeft[frontsLeft.length-1],1);
		for(i=0;i<frontsLeft.length;i++){
			if(frontsLeft[i].edgeReached) frontsLeft[i].edgeReached=false;
			frontsLeft[i].setCurrentStep(frontsLeft[i].mCurrentStep-2);
		}
	}
	drawScene();
}

function nextFrame(){
	var i=0;
	if (lightEmission){
		//ΦΩΤΕΙΝΗ ΠΗΓΗ
		if (frontsLeft.length>0 && !frontsLeft[0].edgeReached) clock1.setValue(clock1.m_Value+1);
		//Δημιουργία επόμενου μετώπου (αν προβλέπεται)
		if(frontsLeft.length==0 || frontsLeft.length>0 && !frontsLeft[0].edgeReached && frontsLeft.length<noOfFronts){
			var newFrontLeft=new waveFront(source1X(),source1Y,context,noOfFronts);
			newFrontLeft.setDirection(0);
			newFrontLeft.setFrontColor(frontRed,frontGreen,frontBlue);
			frontsLeft.push(newFrontLeft);
		}
		//Διάδοση μετώπων
		for(i=0;i<frontsLeft.length;i++){
			if (!frontsLeft[i].edgeReached) frontsLeft[i].propagate();		
		}
		if(Math.abs(frontsLeft[0].xCenter+frontsLeft[0].R-(observerLeft+observer.width/2))<=2){
			for(i=0;i<frontsLeft.length;i++){
				frontsLeft[i].edgeReached=true;
			}
		}
	}
	else{
		if(!bullsEye){
			bulletLeft=bulletLeft+bulletSpeed+wagonVel;
			clock1.setValue(clock1.m_Value+1);
		}
		if(Math.abs(bulletLeft-observerLeft)<=2 || bulletLeft>observerLeft || bulletLeft<0){
			bullsEye=true;
		}
	}
	drawScene();
}

function reset(){
	bullsEye=false;
	clock1.setValue(clock1.m_MinValue);
	clock1.m_Cycles=0;
	initialiseBackground();
	setSource1Xpos(wagonLeft+wagon.width-10);
	initialiseFronts();
	initialiseBullet();
	drawScene();
}

function drawScene(){
	var i=0;
	if (experimentInitialised){
		clearGraphics();
		drawBackground();
		showGrid();
		if (lightEmission){
			for(i=0;i<frontsLeft.length;i++){
				frontsLeft[i].show();
			}
		}
		else{
			drawParticle();
		}
		drawConnectingLine();
		drawClocks();
		drawObserver();
		printValues();
	}
}

function drawConnectingLine(){
	context.setLineDash([5,5]);
	if (lightEmission){
		if (frontsLeft.length>0){
			context.beginPath();
			context.moveTo(source1X(),source1Y);
			context.lineTo(source1X()+frontsLeft[0].R,source1Y);
			context.stroke();
		}
	}
	else{
		context.beginPath();
		context.moveTo(source1X(),source1Y);
		context.lineTo(bulletLeft,source1Y);
		context.stroke();
	}
	context.setLineDash([]);
}

function setFrontsColor(){
	var i=0;
	for(i=0;i<frontsLeft.length;i++){
		frontsLeft[i].mRed=frontRed;
		frontsLeft[i].mGreen=frontGreen;
		frontsLeft[i].mBlue=frontBlue;
	}
}

function setSource1Xpos(newValue){
	source1Xpos=newValue;
	initialiseFronts();
}

function initialiseBackground(){
	trackTop=canvas.height-tracks.height+1;
	wagonTop=trackTop-wagon.height;
	source1Y=wagonTop+4*wagon.height/5-4;
	wagonLeft=-wagon.width/2;
}

function source1X(){
	return source1Xpos;
}

function drawBackground(){
    for (var i=0;i<canvas.width;i+=tracks.width){
    	context.drawImage(tracks,i,trackTop);
    }
    if(!(frontsLeft.length>0 && frontsLeft[0].edgeReached || bullsEye)){
    	wagonLeft=wagonLeft+wagonVel;
    }
    context.drawImage(wagon,wagonLeft,wagonTop);
}

function drawClocks(){
	clock1.show();
}

function drawObserver(){
	context.drawImage(observer,observerLeft,observerTop);
}

function printValues(){
	//πίνακας τιμών
	var valueRound=1;
	var valuesX=450,y=50;
	var t=clock1.m_Cycles*60+clock1.m_Value;
	var lightSpeed=0;
	var classicalSpeed=wagonVel+bulletSpeed;
	var x=0;
	if (lightEmission){
		x=3*t;//frontsLeft[0].R;
	}
	else{
		x=classicalSpeed*t;
	}
	if(t>0) lightSpeed=parseInt(valueRound*x/t)/(valueRound);
	context.font="20px Georgia";
	context.fillStyle="rgb(0,0,0)";
	context.fillText("υβ="+wagonVel,valuesX,y);
	y+=30;
	context.fillText("t="+t,valuesX,y);
	y+=30;
	context.fillText("x="+x,valuesX,y);
	y+=30;
	if (lightEmission){
		context.fillText("c="+lightSpeed,valuesX,y);
		y+=30;
	}
	else{
		context.fillText("σχετική υ="+bulletSpeed,valuesX,y);
		y+=30;
		context.fillText("απόλυτη υ="+classicalSpeed,valuesX,y);
	}
}

function drawParticle(){
	context.strokeStyle="rgb(255,0,0)";
	context.fillStyle="rgb(255,255,0)";
	context.beginPath();
	context.arc(bulletLeft,source1Y,4,0,2*Math.PI);
	context.stroke();
	context.fill();
}